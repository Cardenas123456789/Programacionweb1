<?php
$costo_almuerzo = 1500;

$nombre = $_POST["nombre"];
$estrato = $_POST["estrato"];
$cantidad = $_POST["cantidad"];

if (is_numeric($estrato) && is_numeric($cantidad) && $cantidad > 0) {
 
    $estrato = (int) $estrato;
    $cantidad = (int) $cantidad;

    if ($estrato <= 2) {
        $total_pagar = 0; 
    } else {
        $total_pagar = $costo_almuerzo * $cantidad; 
    }

    echo "<h1>Recibo</h1>";
    echo "Hola Señor@: " . ucfirst($nombre) . ", usted debe pagar: $" . number_format($total_pagar, 0, ",", ".");
} else {
    
    echo "Por favor, ingrese valores válidos para todos los campos.";
}
?>


