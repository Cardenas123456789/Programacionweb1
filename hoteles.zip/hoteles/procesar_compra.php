<?php

$cantidad = $_POST["cantidad"];
$total = 1500 * $cantidad;
//echo "El total a pagar es de " .$total. "pesos";

if($cantidad >= 5) {
    // cuando si
    $des = $total * 0.1;
    $total = $total - $des;
    echo "el total a pagar con su descuento " .$total;
 }else 
 {
   // cuando no
   echo "el total a pagar es " .$total; 
 }

?>