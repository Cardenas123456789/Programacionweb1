<?php

$cervezas = [
    "poker" => 3000,
    "aguila" => 3500,
    "costena" => 3000,
    "corona" => 4000
];

$tipo = $_POST["cerveza"];
$cantidad = $_POST["cantidad"];

if (!isset($cervezas[$tipo])) {
    echo "Tipo de cerveza no válido.";
    exit;
}

$precio_unitario = $cervezas[$tipo];
$subtotal = $precio_unitario * $cantidad;
$iva = $subtotal * 0.19;
$total = $subtotal + $iva;

echo "<h2>Resumen de Compra</h2>";
echo "Cerveza seleccionada: " . ucfirst($tipo) . "<br>";
echo "Cantidad: " . $cantidad . "<br>";
echo "Subtotal: $" . number_format($subtotal, 2) . "<br>";
echo "IVA (19%): $" . number_format($iva, 2) . "<br>";
echo "Total a pagar: $" . number_format($total, 2) . "<br>";

?>
