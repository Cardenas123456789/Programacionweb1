<?php
$poker = $_POST["poker"];
$aguila = $_POST["aguila"];
$costena = $_POST["costena"];
$corona = $_POST["corona"];

$total = ($poker * 3000) + ($aguila * 3500) + ($costena * 3000) + ($corona * 4000);
$iva = $total * 0.19;
$total_con_iva = $total + $iva;

echo "Total sin IVA: $" . $total . "<br>";
echo "IVA (19%): $" . $iva . "<br>";
echo "Total a pagar: $" . $total_con_iva;
?>
