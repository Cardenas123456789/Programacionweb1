<?php
// Precios de las cervezas
$precios = [
    "poker" => 3000,
    "aguila" => 3500,
    "costena" => 3000,
    "corona" => 4000
];

// Capturar cantidades del formulario
$cantidades = [
    "poker" => isset($_POST["poker"]) ? (int)$_POST["poker"] : 0,
    "aguila" => isset($_POST["aguila"]) ? (int)$_POST["aguila"] : 0,
    "costena" => isset($_POST["costena"]) ? (int)$_POST["costena"] : 0,
    "corona" => isset($_POST["corona"]) ? (int)$_POST["corona"] : 0
];

// Calcular el total antes de impuestos
$total_sin_iva = 0;
foreach ($cantidades as $cerveza => $cantidad) {
    $total_sin_iva += $cantidad * $precios[$cerveza];
}

// Aplicar el IVA (19%)
$iva = $total_sin_iva * 0.19;
$total_con_iva = $total_sin_iva + $iva;

// Mostrar el total
echo "<h1>Resumen de compra</h1>";
echo "<ul>";
foreach ($cantidades as $cerveza => $cantidad) {
    if ($cantidad > 0) {
        echo "<li>$cantidad x " . ucfirst($cerveza) . " ($" . number_format($precios[$cerveza], 0, ',', '.') . " c/u)</li>";
    }
}
echo "</ul>";
echo "<p>Total sin IVA: $" . number_format($total_sin_iva, 0, ',', '.') . "</p>";
echo "<p>IVA (19%): $" . number_format($iva, 0, ',', '.') . "</p>";
echo "<h3>Total a pagar: $" . number_format($total_con_iva, 0, ',', '.') . "</h3>";
?>
