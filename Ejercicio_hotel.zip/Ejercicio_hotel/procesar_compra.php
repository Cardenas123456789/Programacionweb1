<?php
$nombre = $_POST["nombre"];
$documento = $_POST["documento"];
$dias = $_POST["dias"];
$tipo = $_POST["tipo"];
$acompanantes = $_POST["acompanantes"];

$precio_base = 100000;
$precio_extra = 30000;

// Calculamos el costo de la habitación
$costo_total = ($precio_base * $dias) + ($precio_extra * $acompanantes * $dias);

if ($tipo == "suite") {
    $costo_total *= 1.10; // Incremento del 10% para la Suite
}

// Mostrar recibo
echo "<h2>Recibo de Pago - Hotel</h2>";
echo "<p><strong>Nombre:</strong> $nombre</p>";
echo "<p><strong>Documento:</strong> $documento</p>";
echo "<p><strong>Días de hospedaje:</strong> $dias</p>";
echo "<p><strong>Tipo de habitación:</strong> " . ucfirst($tipo) . "</p>";
echo "<p><strong>Acompañantes:</strong> $acompanantes</p>";
echo "<h3>Total a pagar: $" . number_format($costo_total, 2) . "</h3>";
?>