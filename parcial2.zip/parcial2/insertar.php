<?php

$dbserver = 'mysql:dbname=parcial_2;host=127.0.0.1';
$user = 'root';
$password = "";

try {
    $dbh = new PDO($dbserver, $user, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cantidad = $_POST['cantidad'];
        $tipo = $_POST['tipo'];
        $aplica_descuento = $_POST['es_madre']; 
        $fecha = date('Y-m-d H:i:s');

        
        if ($tipo == "gaseosa") {
            $precio_unitario = 6000;
        } elseif ($tipo == "cerveza") {
            $precio_unitario = 8000;
        } elseif ($tipo == "aguardiente") {
            $precio_unitario = 10000;
        } else {
            die("Error: Tipo de michelada no válido.");
        }

        
        $valor_total = $cantidad * $precio_unitario;

        
        if ($aplica_descuento == "si") {
            $valor_total = $valor_total * 0.95; 
        }

       
        $sql = "INSERT INTO ventas_micheladas (created_at, tipo, cantidad, apliaca_descuento, valor_ventas) 
                VALUES ('$fecha', '$tipo', '$cantidad', '$aplica_descuento', '$valor_total')";

        $dbh->exec($sql);

        
        echo "<h2>¡Venta registrada con éxito!</h2>";
        echo "<p>Tipo de michelada: <strong>" . ucfirst($tipo) . "</strong></p>";
        echo "<p>Cantidad: <strong>" . $cantidad . "</strong></p>";
        echo "<p>Precio unitario: <strong>$" . number_format($precio_unitario, 0, ',', '.') . "</strong></p>";
        echo "<p>¿Aplica descuento?: <strong>" . ucfirst($aplica_descuento) . "</strong></p>";
        echo "<p>Total a pagar: <strong>$" . number_format($valor_total, 0, ',', '.') . "</strong></p>";
    }

} catch (PDOException $e) {
    echo 'Error de conexión: ' . $e->getMessage();
}
?>
