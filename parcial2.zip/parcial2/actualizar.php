<?php
$conexion = mysqli_connect("localhost", "root", "", "parcial_2");

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

$id = $_POST['id'];
$apliaca_descuento = $_POST['apliaca_descuento'];

$sql = "UPDATE ventas_micheladas SET apliaca_descuento = '$apliaca_descuento' WHERE id = '$id'";

if (mysqli_query($conexion, $sql)) {
    echo "Venta actualizada correctamente.";
} else {
    echo "Error al actualizar: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
