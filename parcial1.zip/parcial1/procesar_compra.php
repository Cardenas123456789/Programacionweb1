<?php

$numero_destino = $_POST["numero_destino"];
$valor_envio = $_POST["valor_envio"];
$comentario = $_POST["comentario"];

$saldo_inicial = 359000;
$comision = $valor_envio * 0.004;
$total_a_descontar = $valor_envio + $comision;

if ($total_a_descontar > $saldo_inicial) {
    echo "<h2>Transacción fallida</h2>";
    echo "No tienes saldo suficiente en tu cuenta.";
} else {
    $saldo_restante = $saldo_inicial - $total_a_descontar;
    
    echo "<h2>Transacción realizada</h2>";
    echo "<p>Número destino: $numero_destino</p>";
    echo "<p>Valor enviado: $$valor_envio</p>";
    echo "<p>Comentario: $comentario</p>";
    echo "<p>Comisión cobrada: $$comision</p>";
    echo "<p>Saldo restante: $$saldo_restante</p>";
}

?>