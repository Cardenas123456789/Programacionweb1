<?php
$dbserver = 'mysql:dbname=empanadas;host=127.0.0.1';
$user = 'root';
$password = "";

$dbh = new PDO($dbserver, $user, $password);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cantidad = $_POST['cantidad'];
    $valor = $_POST['valor'];
    $total = $cantidad * $valor;
    $fecha = date('Y-m-d H:i:s');

    $sql = "INSERT INTO ventas (created_at, cantidad, valor, total) VALUES ('$fecha', '$cantidad', '$valor', '$total')";
    $dbh->exec($sql);

    echo "<h2>¡Venta registrada con éxito!</h2>";
    echo "<p>Empanadas compradas: <strong>" . $cantidad . "</strong></p>";
    echo "<p>Valor por unidad: <strong>" . $valor . "</strong></p>";
    echo "<p>Total a pagar: <strong>" . $total . "</strong></p>";
}
?>
