<?php
$conexion = mysqli_connect("localhost", "root", "", "empanadas");

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

$id = $_POST['id'];
$cantidad = $_POST['cantidad'];
$valor = $_POST['valor'];


$sql = "UPDATE ventas SET cantidad = '$cantidad', valor = '$valor' WHERE id = '$id'";

if (mysqli_query($conexion, $sql)) {
    echo "Venta actualizada correctamente.";
} else {
    echo "Error al actualizar: " . mysqli_error($conexion);
}
mysqli_close($conexion);
?>
