<?php

$nombre = $_POST["nombre"];
$documento = $_POST["documento"];
$dias = $_POST["dias"];
$tipo = $_POST["tipo"];
$acompanantes = $_POST["acompanantes"];

$precio_base = 100000;
$precio_extra = 30000;

// Cálculo del costo total
$total_sin_extra = $precio_base * $dias;
$total_acompanantes = $precio_extra * $acompanantes * $dias;
$costo_total = $total_sin_extra + $total_acompanantes;

if ($tipo == "suite") {
    $incremento_suite = $costo_total * 0.10; // 10% extra
    $costo_total += $incremento_suite;
} else {
    $incremento_suite = 0;
}

// Mostrar recibo
echo "<h2>Recibo de Pago - Hotel</h2>";
echo "<p><strong>Nombre:</strong> " . $nombre . "</p>";
echo "<p><strong>Documento:</strong> " . $documento . "</p>";
echo "<p><strong>Días de hospedaje:</strong> " . $dias . "</p>";
echo "<p><strong>Tipo de habitación:</strong> " . ucfirst($tipo) . "</p>";
echo "<p><strong>Acompañantes:</strong> " . $acompanantes . "</p>";
echo "<p><strong>Total sin extras:</strong> $" . number_format($total_sin_extra, 2) . "</p>";
echo "<p><strong>Costo por acompañantes:</strong> $" . number_format($total_acompanantes, 2) . "</p>";

if ($tipo == "suite") {
    echo "<p><strong>Incremento por Suite (10%):</strong> $" . number_format($incremento_suite, 2) . "</p>";
}

echo "<h3>Total a pagar: $" . number_format($costo_total, 2) . "</h3>";

?>